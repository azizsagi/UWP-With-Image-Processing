﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AForge;
using AForge.Imaging;
using AForge.Imaging.Filters;
using Windows.Graphics.Imaging;
using Windows.Storage;
using Windows.Storage.Streams;
using Windows.UI.Xaml.Media.Imaging;
using System.Runtime.InteropServices.WindowsRuntime;

namespace ImageProcessing
{
    class ImageCorrector
    {
        public async Task<StorageFile> Correct(StorageFile file, int width, int height)
        {
            try
            {
                bool isVertical = true;
                if (width > height)
                    isVertical = false;
                //var folder = await Windows.ApplicationModel.Package.Current.InstalledLocation.GetFolderAsync("TempState");
                //var fileName = "picture" + counter.ToString().PadLeft(3, '0') + ".jpg";
                //counter = counter + 1;

                //var file = await folder.GetFileAsync(fileName);
                var stream = await file.OpenAsync(Windows.Storage.FileAccessMode.Read);
                var originalBitmap = (Bitmap)await BitmapFactory.New(1, 1).FromStream(stream.AsStream());


                //originalBitmap = AForge.Imaging.Image.Clone(originalBitmap, PixelFormat.Format24bppRgb);

                var resizeFilter = new ResizeBilinear(originalBitmap.Width / 10, originalBitmap.Height / 10);

                var bitmap = resizeFilter.Apply(originalBitmap);

                //OriginalImage.Source = (WriteableBitmap)originalBitmap;



                var contrastFilter = new ContrastCorrection();
                contrastFilter.Factor = 50;
                bitmap = contrastFilter.Apply(bitmap);

                var statistics = new AForge.Imaging.ImageStatistics(bitmap);
                var std = statistics.Red.StdDev;
                var channel = RGB.R;

                if (statistics.Green.StdDev > std)
                {
                    channel = RGB.G;
                    std = statistics.Green.StdDev;
                }

                if (statistics.Blue.StdDev > std)
                {
                    channel = RGB.B;
                    std = statistics.Blue.StdDev;
                }

                if (std > 70)
                {
                    var extractChannel = new ExtractChannel();
                    extractChannel.Channel = channel;
                    bitmap = extractChannel.Apply(bitmap);
                }
                else
                {
                    var extractNormalizedRGBChannelFilter = new ExtractNormalizedRGBChannel();
                    extractNormalizedRGBChannelFilter.Channel = channel;
                    bitmap = extractNormalizedRGBChannelFilter.Apply(bitmap);
                }

                //var erosionFilter = new Erosion();
                //bitmap = erosionFilter.Apply(bitmap);

                var otsuThresholdFilter = new OtsuThreshold();
                bitmap = otsuThresholdFilter.Apply(bitmap);

                //bitmap = erosionFilter.Apply(bitmap);

                resizeFilter = new ResizeBilinear(originalBitmap.Width, originalBitmap.Height);
                bitmap = resizeFilter.Apply(bitmap);

                var biggestBlob = new ExtractBiggestBlob();
                bitmap = biggestBlob.Apply(bitmap);

                var quadrilateralFinder = new QuadrilateralFinder();
                var corners = quadrilateralFinder.ProcessImage(bitmap);

                var transformedCorners = new List<IntPoint>();
                foreach (var corner in corners)
                {
                    var transformedCorner = new IntPoint(corner.X + biggestBlob.BlobPosition.X, corner.Y + biggestBlob.BlobPosition.Y);
                    transformedCorners.Add(transformedCorner);
                }
                transformedCorners = SortCorners(transformedCorners, isVertical);

                var quadrilateralTransformation = new QuadrilateralTransformation(transformedCorners, width, height);
                bitmap = quadrilateralTransformation.Apply(originalBitmap);

                var grayScale = Grayscale.CommonAlgorithms.RMY;
                bitmap = grayScale.Apply(bitmap);

                var localThresholding = new BradleyLocalThresholding();
                localThresholding.PixelBrightnessDifferenceLimit = 0.10F;
                bitmap = localThresholding.Apply(bitmap);

                var erosion = new BinaryErosion3x3();
                bitmap = erosion.Apply(bitmap);

                var processedImage = (WriteableBitmap)bitmap;

                StorageFolder folder = ApplicationData.Current.LocalFolder;
                var outputFile = await folder.CreateFileAsync("temp.jpg", CreationCollisionOption.ReplaceExisting);
                using (IRandomAccessStream writerStream = await outputFile.OpenAsync(FileAccessMode.ReadWrite))
                {
                    BitmapEncoder encoder = await BitmapEncoder.CreateAsync(BitmapEncoder.JpegEncoderId, writerStream);
                    Stream pixelStream = processedImage.PixelBuffer.AsStream();
                    byte[] pixels = new byte[pixelStream.Length];
                    await pixelStream.ReadAsync(pixels, 0, pixels.Length);

                    encoder.SetPixelData(BitmapPixelFormat.Bgra8, BitmapAlphaMode.Ignore,
                                        (uint)(processedImage).PixelWidth,
                                        (uint)(processedImage).PixelHeight,
                                        96.0,
                                        96.0,
                                        pixels);
                    await encoder.FlushAsync();

                    using (var outputStream = writerStream.GetOutputStreamAt(0))
                    {
                        await outputStream.FlushAsync();
                    }
                }

                return outputFile;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private int FindSmallestEdgeIndex(List<IntPoint> transformedCorners)
        {
            int maxDistance = int.MaxValue;
            int index = 0;
            for (int i = 0; i < transformedCorners.Count; i++)
            {
                var point1 = transformedCorners.ElementAt(i);
                var point2 = transformedCorners.ElementAt((i + 1) % transformedCorners.Count);
                var distance = (point1.X - point2.X) * (point1.X - point2.X) + (point1.Y - point2.Y) * (point1.Y - point2.Y);
                if (distance < maxDistance)
                {
                    maxDistance = distance;
                    index = i;
                }
            }
            return index;
        }

        private List<IntPoint> SortCorners(List<IntPoint> transformedCorners, bool isVertical = true)
        {
            int startIndex = FindSmallestEdgeIndex(transformedCorners);
            if (!isVertical)
            {
                startIndex = (startIndex + transformedCorners.Count - 1) % transformedCorners.Count;
            }
            if (transformedCorners.Count == 4)
            {
                var newCorners = new List<IntPoint>();
                for (int i = 0; i < transformedCorners.Count; i++)
                {
                    var index = startIndex % transformedCorners.Count;
                    newCorners.Add(transformedCorners.ElementAt(index));
                    startIndex++;
                }
                return newCorners;


            }
            return transformedCorners;
        }

    }
}
