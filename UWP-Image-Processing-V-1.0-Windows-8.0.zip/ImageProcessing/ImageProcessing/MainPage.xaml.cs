﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace ImageProcessing
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private StorageFile currentImageFile;

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            
        }


        private async Task<bool> ProcessImage()
        {
            try
            {
                Windows.Storage.StorageFolder storageFolder = Windows.Storage.ApplicationData.Current.LocalFolder;
                currentImageFile = await storageFolder.GetFileAsync("testImage.JPG");

                var imageCorrector = new ImageCorrector();
                currentImageFile = await imageCorrector.Correct(currentImageFile, 1200, 650);
                processedImage.Source = new BitmapImage(new Uri( Windows.Storage.ApplicationData.Current.LocalFolder.Path + "/temp.jpg"));
                return true;
            }
            catch (Exception ex)
            {
                var messageDialog = new MessageDialog(ex.Message);
                messageDialog.ShowAsync();
            }
            return false;
        }

        public async void Button_Click(object sender, RoutedEventArgs e)
        {
            var processImageResult = await ProcessImage();

            //if (processImageResult)
            //{
            //    processedImage.Source = currentImageFile.Path.ToString();
            //}
        }

    }
}
